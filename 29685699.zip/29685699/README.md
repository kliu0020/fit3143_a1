# fit3143_a1
Assignment 1, analysing the time taken in sequential and parallelized versions of blooms filter algorithm with simple hashing functions to determine the result of openmp on blooms filter
